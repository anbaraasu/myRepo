package com.bootcamp.microservicewebclient;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MicroserviceWebclientApplicationTests {

	@Test
	void contextLoads() {
		
	}

}
