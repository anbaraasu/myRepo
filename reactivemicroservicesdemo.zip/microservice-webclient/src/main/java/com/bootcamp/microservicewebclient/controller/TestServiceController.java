package com.bootcamp.microservicewebclient.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.bootcamp.microservicewebclient.model.Player;

@RestController
public class TestServiceController {

	private static final String HTTP_FIFASQUADSERVICE_FIFA_PLAYERS = "http://FIFASQUADSERVICE/fifa/";

	@Autowired
	RestTemplate req;

	@GetMapping("/test/players")
	public List<Player> getPlayers() {
		return req.getForObject(HTTP_FIFASQUADSERVICE_FIFA_PLAYERS + "players", List.class);
	}

	@GetMapping("/test/myFavPlayers")
	public String getMyFavPlayers() {
		return req.getForObject(HTTP_FIFASQUADSERVICE_FIFA_PLAYERS + "myFavPlayers", String.class);
	}

}
