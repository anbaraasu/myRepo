package com.bootcamp.microservicewebclient.model;


import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class Player {
	private int id;
	private String name;
	private String position;
	private String squad;
	private int matchesPlayed;
	private int goalsScored;
}
