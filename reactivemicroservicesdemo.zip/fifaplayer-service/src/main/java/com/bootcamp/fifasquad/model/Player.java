package com.bootcamp.fifasquad.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.relational.core.mapping.Column;
import org.springframework.data.relational.core.mapping.Table;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@Table
public class Player {
	@Id
	private int id;
	private String name;
	private String position;
	private String squad;
	@Column("MATCHESPLAYED")
	private int matchesPlayed;
	@Column("GOALSSCORED")
	private int goalsScored;
}
