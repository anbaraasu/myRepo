package com.bootcamp.fifasquad.controller;

import java.time.Duration;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.bootcamp.fifasquad.model.Player;
import com.bootcamp.fifasquad.service.PlayerService;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@RestController
@RequestMapping("/fifa")
public class PlayerController {
	@Autowired
	PlayerService playerService;

	@GetMapping("/myFavPlayers")
	public Mono<String> getMyFavPlayers() {
		return Mono.just("My Favorite players are Messi, Ronaldo, Neymar");
	}
	
	@GetMapping("/players")
	public Flux<Player> getPlayers() {
		return playerService.getPlayers();//.delayElements(Duration.ofMillis(1000));
	}
	
	@PostMapping("/player")
	@ResponseStatus(HttpStatus.CREATED)
	public Mono<String> createPlayer(@RequestBody Player player){
		return playerService.createPlayer(player);
	} 
	@PutMapping("/player")
	public Mono<Player> updatePlayer(@RequestBody Player player,@RequestParam int id){
		return playerService.updatePlayer(player,id);
	} 
	@DeleteMapping("/player")
	public Mono<Void> deletePlayer(@RequestParam int id){
		return playerService.deletePlayer(id);
	} 
	@GetMapping("/player")
	public Mono<Player> getPlayer(@RequestParam int id){
		return playerService.getPlayerById(id);
	} 
}