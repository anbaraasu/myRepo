package com.bootcamp.fifasquad.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bootcamp.fifasquad.model.Player;
import com.bootcamp.fifasquad.repository.PlayerRepository;

import jakarta.ws.rs.NotFoundException;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Service
public class PlayerService {
	@Autowired
	PlayerRepository playerRepo;

	public Flux<Player> getPlayers() {
		return playerRepo.findAll();
	}

	public Mono<Player> getPlayerById(int id) {
		return playerRepo.findById(id);
	}

	public Mono<String> createPlayer(Player player) {
		return playerRepo.save(player).flatMap(result -> {
			if (result.getId() > 0) {
				return Mono.just("Successfully created");
			} else {
				return Mono.just("Error in creating player details");
			}
		}).onErrorReturn(Exception.class, "Error in creating player details");
	}

	public Mono<Player> updatePlayer(Player player, int id) {
		return playerRepo.findById(id)
                .switchIfEmpty(Mono.error(new NotFoundException(String.valueOf(id))))
                .flatMap(p -> playerRepo.save(player))
                // Query again for can't get id in H2
                .flatMap(p -> playerRepo.findById(p.getId()));
	}

	public Mono<Void> deletePlayer(int id) {
		return playerRepo.findById(id).switchIfEmpty(Mono.error(new NotFoundException(String.valueOf(id))))
				.then(playerRepo.deleteById(id));

	}
}
