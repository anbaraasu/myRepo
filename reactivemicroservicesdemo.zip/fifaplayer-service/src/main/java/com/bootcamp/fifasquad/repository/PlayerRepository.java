package com.bootcamp.fifasquad.repository;

import org.springframework.data.r2dbc.repository.Modifying;
import org.springframework.data.r2dbc.repository.Query;
import org.springframework.data.repository.reactive.ReactiveCrudRepository;
import org.springframework.transaction.annotation.Transactional;

import com.bootcamp.fifasquad.model.Player;

import reactor.core.publisher.Mono;

public interface PlayerRepository extends ReactiveCrudRepository<Player, Integer> {

	@Modifying
	@Transactional
	@Query("DELETE FROM Player t where t.id = :#{[0]}")
	Mono<Void> deleteById(Integer id);
}
